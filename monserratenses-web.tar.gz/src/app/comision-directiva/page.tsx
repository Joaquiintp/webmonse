'use client';

import { useEffect, useState } from 'react';

export default function ComisionDirectiva() {
  const [isVisible, setIsVisible] = useState(false);
  const [actaUrl, setActaUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsVisible(true);
    
    const fetchActa = async () => {
      try {
        const STRAPI_URL = process.env.NEXT_PUBLIC_STRAPI_URL || 'http://localhost:1337';
        
        // Fetch desde Strapi - Single Type con campo "archivo"
        const url = `${STRAPI_URL}/api/acta?populate=archivo`;
        console.log('📡 Fetching:', url);
        
        const response = await fetch(url);
        console.log('📊 Response status:', response.status);
        
        if (!response.ok) {
          console.error('❌ Error HTTP:', response.status, response.statusText);
          setIsLoading(false);
          return;
        }
        
        const json = await response.json();
        console.log('📦 JSON completo:', json);
        
        if (json && json.data && json.data.archivo) {
          const archivo = json.data.archivo;
          console.log('📄 Archivo encontrado:', archivo);
          
          // En Strapi v5, el archivo puede estar directamente o en .data
          let pdfUrl = null;
          
          if (archivo.url) {
            pdfUrl = archivo.url;
          } else if (archivo.data && archivo.data.url) {
            pdfUrl = archivo.data.url;
          }
          
          if (pdfUrl) {
            const fullUrl = `${STRAPI_URL}${pdfUrl}`;
            console.log('✅ URL del PDF:', fullUrl);
            setActaUrl(fullUrl);
          } else {
            console.log('❌ No se encontró URL en archivo:', archivo);
          }
        } else {
          console.log('❌ No se encontró archivo en data');
        }
        
        setIsLoading(false);
      } catch (error) {
        console.error('💥 Error:', error);
        setIsLoading(false);
      }
    };

    fetchActa();
  }, []);

  return (
    <>
      <section 
        className="relative min-h-[60vh] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: 'url(/images/fuente-patio-menor-monserrat.jpg)',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center 90%'
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-25"></div>
        
        <div className={`relative z-10 text-center transition-all duration-1000 ease-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <p 
            className="text-sm md:text-base font-semibold text-white mb-4 uppercase tracking-wider"
            style={{ 
              fontFamily: 'Barlow, sans-serif',
              textShadow: '2px 2px 8px rgba(0,0,0,0.8)',
              letterSpacing: '3px'
            }}
          >
            Quiénes somos
          </p>
          <h1 
            className="text-6xl md:text-7xl font-bold text-white mb-8"
            style={{ 
              fontFamily: 'Lora, Georgia, serif',
              textShadow: '3px 3px 10px rgba(0,0,0,0.8)'
            }}
          >
            Comisión Directiva
          </h1>
          
          {isLoading ? (
            <button
              disabled
              className="inline-block bg-gray-300 text-gray-600 px-8 py-3 rounded-full font-semibold uppercase tracking-wider cursor-not-allowed opacity-50"
              style={{ 
                fontFamily: 'Oswald, sans-serif',
                fontSize: '14px',
                letterSpacing: '2px'
              }}
            >
              Cargando...
            </button>
          ) : actaUrl ? (
            <a
              href={actaUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-[#ebe4d3] text-[#625352] px-8 py-3 rounded-full font-semibold uppercase tracking-wider hover:bg-[#625352] hover:text-[#ebe4d3] transition-all duration-300"
              style={{ 
                fontFamily: 'Oswald, sans-serif',
                fontSize: '14px',
                letterSpacing: '2px'
              }}
            >
              Acta Constitutiva
            </a>
          ) : null}
        </div>
      </section>

      <section className="py-20 md:py-32 bg-[#faf8f3]">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="space-y-8">
            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Adrián Guillermo Rodríguez
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Presidente
              </p>
            </div>

            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Jorge Alberto López
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Secretario
              </p>
            </div>

            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Carla López Micieli
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Tesorera
              </p>
            </div>

            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Jorge Martín Giménez
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Vocal Titular
              </p>
            </div>

            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Antonio Luis Rodríguez
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Vocal Suplente
              </p>
            </div>

            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Marcelo Rafael González
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Revisor de Cuentas Titular
              </p>
            </div>

            <div className="text-center">
              <h3 
                className="text-2xl md:text-3xl font-bold text-[#5e1415] mb-2"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                Diego Blázquez
              </h3>
              <p 
                className="text-sm md:text-base text-gray-600 uppercase tracking-wider"
                style={{ fontFamily: 'Barlow, sans-serif', letterSpacing: '2px' }}
              >
                Revisor de Cuentas Suplente
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

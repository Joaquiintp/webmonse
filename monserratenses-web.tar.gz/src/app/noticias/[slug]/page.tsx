import { getNoticiaBySlug } from '@/lib/strapi-news'
import Image from 'next/image'
import Link from 'next/link'

export const dynamic = 'force-dynamic'

export default async function NoticiaPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const noticia = await getNoticiaBySlug(slug)

  if (!noticia) {
    return <div>Noticia no encontrada</div>
  }

  const imageUrl = `http://168.231.99.125:1337${noticia.foto?.url || '/uploads/default.jpg'}`
  const tieneVideo = noticia.url ? noticia.url.trim() !== '' : false
  const tieneParrafo2 = noticia.parrafo2 ? noticia.parrafo2.trim() !== '' : false

  return (
    <>
      <section
        className="relative min-h-[60vh] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url(${imageUrl})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <h1 
            className="text-4xl md:text-6xl font-bold text-white mb-4"
            style={{ 
              fontFamily: 'Lora, Georgia, serif',
              textShadow: '3px 3px 12px rgba(0,0,0,0.9)'
            }}
          >
            {noticia.titulo}
          </h1>
          <p 
            className="text-lg md:text-xl text-white/90"
            style={{ 
              fontFamily: 'Barlow, sans-serif',
              textShadow: '2px 2px 8px rgba(0,0,0,0.8)'
            }}
          >
            {new Date(noticia.publishedAt).toLocaleDateString('es-AR', {
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>
        </div>
      </section>

      <section className="py-16 px-4 bg-[#faf8f3]">
        <div className="max-w-4xl mx-auto">
          <article className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
            {!tieneVideo && !tieneParrafo2 && (
              <div className="relative w-full h-96 mb-8 rounded-xl overflow-hidden shadow-lg">
                <Image
                  src={imageUrl}
                  alt={noticia.titulo}
                  fill
                  className="object-cover"
                />
              </div>
            )}

            <div className="prose prose-lg max-w-none">
              <p
                className="text-xl leading-relaxed text-slate-700 whitespace-pre-line"
                style={{ fontFamily: 'Lora, Georgia, serif' }}
              >
                {noticia.parrafo1}
              </p>

              {tieneVideo && !tieneParrafo2 && (
                <div className="my-12">
                  <div className="relative w-full pb-[56.25%] rounded-lg overflow-hidden shadow-xl">
                    <iframe
                      src={noticia.url || ""}
                      title={noticia.titulo}
                      className="absolute top-0 left-0 w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                </div>
              )}

              {tieneParrafo2 && (
                <>
                  <div className="relative w-full h-96 my-8 rounded-xl overflow-hidden shadow-lg">
                    <Image
                      src={imageUrl}
                      alt={noticia.titulo}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <p
                    className="text-xl leading-relaxed text-slate-700 whitespace-pre-line"
                    style={{ fontFamily: 'Lora, Georgia, serif' }}
                  >
                    {noticia.parrafo2}
                  </p>
                </>
              )}

              {tieneVideo && tieneParrafo2 && (
                <div className="my-12">
                  <div className="relative w-full pb-[56.25%] rounded-lg overflow-hidden shadow-xl">
                    <iframe
                      src={noticia.url || ""}
                      title={noticia.titulo}
                      className="absolute top-0 left-0 w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="mt-12 text-center border-t border-slate-200 pt-8">
              <Link
                href="/noticias"
                className="inline-flex items-center gap-2 bg-[#5e1415] hover:bg-[#4a1011] text-white px-8 py-4 rounded-full font-semibold transition-all transform hover:scale-105 shadow-lg"
                style={{ fontFamily: 'Barlow, sans-serif' }}
              >
                ← Volver a Noticias
              </Link>
            </div>
          </article>
        </div>
      </section>
    </>
  )
}

import Image from 'next/image'
import Link from 'next/link'
import { getNoticias, getNoticiaImageUrl, getNoticiaExcerpt } from '@/lib/strapi-news'

export default async function NoticiasPage() {
  const allNoticias = await getNoticias() // Sin límite, trae todas
  
  // Filtrar noticias válidas (con datos completos)
  const noticias = allNoticias.filter(noticia => 
    noticia.titulo && 
    noticia.parrafo1 && 
    (noticia.slug || noticia.documentId)
  )

  return (
    <>
      {/* Banner */}
      <section
        className="relative min-h-[45vh] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: 'url(/images/fuente-patio-menor-monserrat.jpg)',
          backgroundSize: 'cover',
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'center 30%',
        }}
      >
        <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        
        <div className="relative z-10 text-center px-4">
          <h1 
            className="text-5xl md:text-6xl font-bold text-white mb-4"
            style={{ 
              fontFamily: 'Lora, Georgia, serif',
              textShadow: '3px 3px 10px rgba(0,0,0,0.8)'
            }}
          >
            Noticias
          </h1>
          <p 
            className="text-xl md:text-2xl text-white"
            style={{ 
              fontFamily: 'Lora, Georgia, serif',
              textShadow: '2px 2px 8px rgba(0,0,0,0.7)'
            }}
          >
            Mantente informado sobre todas nuestras actividades
          </p>
        </div>
      </section>

      {/* Grid de Noticias */}
      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-7xl mx-auto">
          {noticias && noticias.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {noticias.map((noticia) => {
                const slug = noticia.slug || noticia.documentId
                const imageUrl = getNoticiaImageUrl(noticia)
                const excerpt = getNoticiaExcerpt(noticia.parrafo1, 120)
                
                return (
                  <Link 
                    key={noticia.documentId}
                    href={`/noticias/${slug}`}
                    className="group bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
                  >
                    <div className="relative h-56 w-full overflow-hidden">
                      <Image
                        src={imageUrl}
                        alt={noticia.titulo}
                        fill
                        className="object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                    <div className="p-6">
                      <h3 
                        className="text-2xl font-bold mb-3 text-slate-900 group-hover:text-[#5e1415] transition-colors"
                        style={{ fontFamily: 'Lora, Georgia, serif' }}
                      >
                        {noticia.titulo}
                      </h3>
                      <p 
                        className="text-slate-600 mb-4 line-clamp-3 leading-relaxed"
                        style={{ fontFamily: 'Lora, Georgia, serif' }}
                      >
                        {excerpt}
                      </p>
                      <span 
                        className="inline-flex items-center text-[#5e1415] font-semibold group-hover:underline"
                        style={{ fontFamily: 'Barlow, sans-serif' }}
                      >
                        Leer más →
                      </span>
                    </div>
                  </Link>
                )
              })}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-xl text-slate-600" style={{ fontFamily: 'Lora, Georgia, serif' }}>
                No hay noticias disponibles en este momento.
              </p>
            </div>
          )}
        </div>
      </section>
    </>
  )
}

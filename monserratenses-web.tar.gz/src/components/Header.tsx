'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useState } from 'react'

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  // Menú desktop - SIN las cartas
  const desktopMenuItems = [
    { href: '/', label: 'Inicio' },
    { href: '/servicios', label: 'Servicios' },
    { href: '/contacto', label: 'Contacto' },
    { href: '/mision-vision-valores', label: 'Misión, visión, valores' },
    { href: '/monserratenses-por-el-mundo', label: 'Monserratenses por el mundo' },
    { href: '/noticias', label: 'Noticias' },
    { href: '/comision-directiva', label: 'Comisión Directiva' },
  ]

  // Menú mobile - CON las cartas
  const mobileMenuItems = [
    { href: '/', label: 'Inicio' },
    { href: '/servicios', label: 'Servicios' },
    { href: '/contacto', label: 'Contacto' },
    { href: '/mision-vision-valores', label: 'Misión, visión, valores' },
    { href: '/carta-abierta-a-los-egresados', label: 'Carta Abierta a los Egresados' },
    { href: '/carta-fundacional', label: 'Carta Fundacional' },
    { href: '/monserratenses-por-el-mundo', label: 'Monserratenses por el mundo' },
    { href: '/noticias', label: 'Noticias' },
    { href: '/comision-directiva', label: 'Comisión Directiva' },
  ]

  return (
    <header className="et-l et-l--header bg-white shadow-md sticky top-0 z-50">
      <div className="flex items-center justify-between px-3 lg:px-4" style={{ width: '90%', maxWidth: '1920px', margin: '0 auto' }}>
            {/* Logo Asociación */}
            <div className="et_pb_column flex items-start justify-start" style={{ width: '30%', marginRight: '2%' }}>
              <div className="et_pb_module et_pb_image flex-shrink-0" style={{ minHeight: '70px', paddingTop: '8px', paddingBottom: '8px' }}>
                <Link href="/">
                  <span className="et_pb_image_wrap block">
                    <Image 
                      src="/images/logo-asociacion-civil-duarte-y-quiros-1.svg"
                      alt="Asociación Civil Duarte y Quirós"
                      width={355}
                      height={164}
                      className="h-[55px] lg:h-[70px] w-auto"
                      priority
                    />
                  </span>
                </Link>
              </div>
            </div>

            {/* Logo LibeRed en el medio */}
            <div className="hidden lg:flex items-center justify-start" style={{ width: '18%', paddingLeft: '0', marginLeft: '-300px', marginTop: '6px' }}>
              <Link href="/libered#tarjeta" className="group">
                <Image
                  src="/images/redliber.svg"
                  alt="LibeRed"
                  width={250}
                  height={88}
                  className="w-auto h-auto object-contain transition-transform duration-300 group-hover:scale-110"
                  style={{ maxHeight: '80px' }}
                />
              </Link>
            </div>

            {/* Desktop Menu - SIN cartas */}
            <div className="et_pb_column hidden lg:block" style={{ width: '53%' }}>
              <nav className="et_pb_menu text-right">
                <ul className="et-menu nav inline-flex justify-end items-center gap-x-6" style={{ maxWidth: '100%', flexWrap: 'wrap' }}>
                  {desktopMenuItems.map((item) => (
                    <li key={item.href} className="inline-block">
                      <Link 
                        href={item.href}
                        className="block text-sm text-gray-600 hover:opacity-70 transition-all duration-400 whitespace-nowrap"
                        style={{ 
                          fontFamily: 'Barlow, Helvetica, Arial, sans-serif',
                          fontSize: '15px',
                          textTransform: 'uppercase',
                          color: 'rgba(0,0,0,0.6)',
                          lineHeight: '1.8'
                        }}
                      >
                        {item.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#5e1415]"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" viewBox="0 0 24 24" stroke="currentColor">
                {mobileMenuOpen ? (
                  <path d="M6 18L18 6M6 6l12 12"></path>
                ) : (
                  <path d="M4 6h16M4 12h16M4 18h16"></path>
                )}
              </svg>
            </button>
      </div>

      {/* Mobile Menu Dropdown - CON cartas */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-gray-200 shadow-lg">
          <nav className="container mx-auto px-3 py-3">
            <ul className="space-y-1">
              {mobileMenuItems.map((item) => (
                <li key={item.href}>
                  <Link 
                    href={item.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="block py-2.5 px-3 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                    style={{ 
                      fontFamily: 'Barlow, Helvetica, Arial, sans-serif',
                      fontSize: '14px',
                      textTransform: 'uppercase'
                    }}
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
              {/* LibeRed en menú móvil */}
              <li className="border-t border-gray-200 pt-1.5 mt-1.5">
                <Link 
                  href="/libered#tarjeta"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-2 py-2.5 px-3 text-[#8B1538] hover:bg-red-50 rounded-lg transition-colors font-semibold"
                >
                  <Image
                    src="/images/redliber.svg"
                    alt="LibeRed"
                    width={70}
                    height={25}
                    className="w-auto h-auto object-contain"
                    style={{ maxHeight: '22px' }}
                  />
                  <span style={{ fontSize: '13px' }}>Tarjeta de Beneficios</span>
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  )
}
